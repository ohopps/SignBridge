import streamlit as st
import time
from datetime import datetime
from speech_module import SpeechEngine
from vision_system import RealVisionSystem

# Configure page
st.set_page_config(page_title="SignBridge", page_icon="🏥", layout="wide")

# Initialize session state variables
if 'history' not in st.session_state:
    st.session_state.history = []
if 'current_text' not in st.session_state:
    st.session_state.current_text = "Waiting for gesture..."
if 'emergency_mode' not in st.session_state:
    st.session_state.emergency_mode = False
if 'handedness' not in st.session_state:
    st.session_state.handedness = 'left'

# Initialize backend systems (run only once)
@st.cache_resource
def get_systems():
    speech = SpeechEngine()
    vision = RealVisionSystem()
    return speech, vision

speech_engine, vision_system = get_systems()

def load_css():
    with open("style.css") as f:
        st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)
        
    if st.session_state.emergency_mode:
        st.markdown('<style>div.stApp { background-color: #FFEBEE; }</style>', unsafe_allow_html=True)
        # Inject an empty div with emergency-mode class so CSS rules apply to children if wrapped
        # But we will handle emergency-mode class directly on the subtitle container.

load_css()

# Sidebar for controls
with st.sidebar:
    st.title("⚙️ Controls")
    
    st.markdown("### User Profile")
    handedness_option = st.radio("Handedness", ["Left Handed", "Right Handed"], index=0 if st.session_state.handedness == 'left' else 1)
    new_handedness = 'left' if handedness_option == "Left Handed" else 'right'
    if new_handedness != st.session_state.handedness:
        st.session_state.handedness = new_handedness
        vision_system.load_model(new_handedness)
        st.rerun()

    st.markdown("---")
    
    # Emergency Mode Toggle
    emergency_toggle = st.toggle("🚨 Emergency Mode", value=st.session_state.emergency_mode)
    if emergency_toggle != st.session_state.emergency_mode:
        st.session_state.emergency_mode = emergency_toggle
        if emergency_toggle:
            speech_engine.say("Emergency mode activated. High priority.")
            st.rerun()
        else:
            speech_engine.say("Emergency mode deactivated.")
            st.rerun()
            
    st.markdown("---")
    st.markdown("### Settings")
    st.slider("Speech Volume", 0, 100, 90, disabled=True, help="Disabled in prototype")
    st.slider("Speech Speed", 50, 250, 150, disabled=True, help="Disabled in prototype")
    
    if st.button("Clear History"):
        st.session_state.history = []
        st.rerun()

# Main Application Layout
if st.session_state.emergency_mode:
    st.markdown("<h1 style='color: #D32F2F;'>🚨 EMERGENCY COMMUNICATION ACTIVE 🚨</h1>", unsafe_allow_html=True)
else:
    st.title("🏥 SignBridge")

col1, col2 = st.columns([2, 1])

with col1:
    st.subheader("Live Camera Feed & Detection")
    # Placeholder for the video feed
    video_placeholder = st.empty()
    
    st.markdown("### Live Subtitles")
    # Subtitle display area
    subtitle_placeholder = st.empty()
    
with col2:
    st.subheader("Translation History")
    # History display area
    history_placeholder = st.empty()

# UI update function
def update_ui(frame, current_text, history, emergency_mode):
    # Display video frame
    if frame is not None:
        video_placeholder.image(frame, channels="RGB", use_container_width=True)
        
    # Update Subtitle UI
    em_class = "emergency-subtitle" if emergency_mode else ""
    subtitle_html = f'''
    <div class="subtitle-container {em_class}">
        <div class="subtitle-text">{current_text}</div>
    </div>
    '''
    subtitle_placeholder.markdown(subtitle_html, unsafe_allow_html=True)
    
    # Update History UI
    history_html = '<div class="history-container">'
    for item in history[:10]: # Show last 10
        history_html += f'<div class="log-entry">{item}</div>'
    history_html += '</div>'
    history_placeholder.markdown(history_html, unsafe_allow_html=True)

# Main loop
try:
    # First update to render the UI before starting the heavy loop
    update_ui(None, st.session_state.current_text, st.session_state.history, st.session_state.emergency_mode)
    
    while True:
        frame, gesture = vision_system.get_frame_and_gesture()
        
        # Process new gesture
        if gesture:
            st.session_state.current_text = gesture
            timestamp = datetime.now().strftime("%H:%M:%S")
            st.session_state.history.insert(0, f"[{timestamp}] {gesture}")
            
            # Speak
            prefix = "Emergency, " if st.session_state.emergency_mode else ""
            speech_engine.say(f"{prefix}{gesture}")
            
        update_ui(frame, st.session_state.current_text, st.session_state.history, st.session_state.emergency_mode)
        
        # Small sleep to reduce CPU usage and allow Streamlit to handle sidebar events (though while loop blocks Streamlit from completing the script)
        time.sleep(0.05)
        
except Exception as e:
    st.error(f"Error: {e}")
finally:
    # We do NOT release the vision_system here because Streamlit re-runs scripts on every interaction.
    # Releasing it would break the camera feed permanently.
    pass

