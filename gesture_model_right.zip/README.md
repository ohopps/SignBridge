# Committee 2: AI Model & Training Pipeline (Alicia)

This folder contains the complete Machine Learning pipeline for building the real-time gesture recognition system. We are using **MediaPipe** to extract 3D hand landmarks, and **Scikit-Learn** to train a lightweight Random Forest model. This approach is highly optimized for hackathons: it trains in seconds and runs inference instantly without requiring a GPU.

## Step 1: Environment Setup

Before running anything, ensure you have Python 3 installed. Then, open your terminal (or command prompt) and install the required dependencies:

```bash
pip install mediapipe opencv-python scikit-learn pandas numpy
```

## Step 2: Collect Sample Data

To train the model, you need to collect samples of yourself performing the gestures.

1. Run the data collection script:
   ```bash
   python collect_data.py
   ```
2. The webcam will open.
3. Perform a gesture in front of the camera.
4. While holding the gesture, press the corresponding number key on your keyboard to save that frame as a data point. (e.g., Press '0' for Help, '1' for Pain).
5. Move your hand slightly and press the key again to capture variations of the same sign. **Aim for about 100-200 frames per sign.**
6. Press 'q' to quit. The data will be saved to `gesture_dataset.csv`.

*Note: You can check the `LABEL_MAP` in the scripts to see which number corresponds to which sign, and you can edit those labels directly in the Python files.*

## Step 3: Train the Model

Once you have a healthy dataset in `gesture_dataset.csv`, it's time to train the ML model.

1. Run the training script:
   ```bash
   python train_model.py
   ```
2. The script will automatically load the CSV, split the data, and train a Random Forest Classifier.
3. It will print the accuracy score and a detailed classification report. 
4. The trained model will be saved as `gesture_model.pkl`.

## Step 4: Test Real-Time Inference

Now you can test your model in real-time.

1. Run the inference script:
   ```bash
   python inference.py
   ```
2. The webcam will open. Perform the gestures you trained the model on.
3. The script will extract the landmarks, pass them to your trained `gesture_model.pkl`, and display the predicted sign on the screen!
4. Press 'q' to quit.

## Troubleshooting

- **No Hands Detected during collection:** Ensure your entire hand is visible in the frame and well-lit.
- **Low Accuracy:** Make sure you collect enough varied samples (different angles, slightly different distances) for each sign. Make sure signs look distinctly different from each other.
